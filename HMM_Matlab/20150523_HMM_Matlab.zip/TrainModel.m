function [model] = TrainModel(trainSet, PARAMETERS)
    % --- Training of the model fo the algorithm (strongly depends on type of algorithm) -----------------------------------
    disp('--- Starting the training of the model for the algorithm ---');
    %Do the training to generate a model
    model = [];
    disp('--- Finished the training of the model for the algorithm ---');
end